#include <stdio.h>
#include <string.h>

typedef char string[255];
typedef struct
{
	int tanggal;
	string bulan;
	int tahun;
}Date;
typedef char string[255];
typedef struct
{
	string jalan;
	int no_jln;
	string kota;
}alamat;
typedef struct
{
	//kartu priksa
	int id_pasien;
    string nama;
	string kelamin;
	Date tgl_lahir;
	string gol_darah;
	alamat alamat;
	int ktp;
	int bpjs;
	Date tgl_daftar;
	int tlp;
	string doktor;
	//riwayat
	Date tgl_priksa;
	int id_riwayat;
	int t_badan;
	int b_badan;
	int umur;
	int tekanan_darah;
	string keluhan;
	string catatan_doktor;
	string resep;
}pasien;


void init(pasien m[]);
void inputDataKartuPasien(pasien m[]);
void inputDataRiwayatPasien(pasien m[]);
void kartu(pasien m[]);
void riwayatPasien(pasien m[]);
void updateDataKartu(pasien m[]);
void updateDataRiwayat(pasien m[]);
void deleteDataKartu(pasien m[]);
void deleteDataRiwayat(pasien m[]);

void main()
{
	int pilihan, input;
	pasien m[5];
	do{
		system("cls");
		puts("===================================");
		puts("[ADI SELAMET PRIYADI NIM 221210012]");
		puts("===================================");
		puts("DATA PASIEN");
		puts("1. inisialisasi data");
		puts("2. Buat kartu pasien");
		puts("3. Masukan riwayat pasein");
		puts("4. Tampilkan kartu pasien");
		puts("5. Tampilkan riwayat pasien");
		puts("6. Update data kartu pasien");
		puts("7. Update data riwayat pasien");
		puts("8. Hapus data paseien");
		puts("9. Hapus data riwayat");
		puts("0. EXIT");
		printf("pilih menu: ");scanf("%d",&pilihan);
		switch(pilihan)
		{
			case 1: init(m);
					getch();
					break;
			case 2: inputDataKartuPasien(m);
					getch();
					break;
			case 3: inputDataRiwayatPasien(m);
					getch();
					break;
			case 4: kartu(m);
					getch();
					break;
			case 5: riwayatPasien(m);
					getch();
					break;
			case 6:	updateDataKartu(m);
					getch();
					break;
			case 7: updateDataRiwayat(m);
					getch();
					break;
			case 8: deleteDataKartu(m);
					printf("!!!DATA KARTU PASEIN BERHAIL DI HAPUS!!!");
					getch();
					break;
			case 9:	deleteDataRiwayat(m);
					printf("!!!DATA RIWAYAT PASEIEN BERHASIL DI HAPUS!!!");
					getch();
					break;
			case 0:  break;
			default : printf("maaf data tidak di temukan !");
					getch();
					break;
		}
	}while(pilihan!=0);
}
void init(pasien m[])
{
	int i;
	for(i=0;i<5;i++){
		//kartu pasien
		m[i].id_pasien=0;
		strcpy(m[i].nama,"-");
		strcpy(m[i].kelamin,"-");
		m[i].tgl_lahir.tanggal=0;
		strcpy(m[i].tgl_lahir.bulan,"-");
		m[i].tgl_lahir.tahun=0;
		strcpy(m[i].gol_darah,"-");
		strcpy(m[i].alamat.jalan,"-");
		m[i].alamat.no_jln=0;
		strcpy(m[i].alamat.kota,"-");
		m[i].ktp=0;
		m[i].bpjs=0;
		m[i].tlp=0;
		m[i].tgl_priksa.tanggal=0;
		strcpy(m[i].tgl_priksa.bulan,"-");
		m[i].tgl_priksa.tahun=0;
		strcpy(m[i].doktor,"-");
		//riwayat pasien
		m[i].tgl_lahir.tanggal=0;
		strcpy(m[i].tgl_lahir.bulan,"-");
		m[i].tgl_lahir.tahun=0;
		m[i].id_riwayat=0;
		m[i].t_badan=0;
		m[i].b_badan=0;
		m[i].umur=0;
		m[i].tekanan_darah=0;
		strcpy(m[i].keluhan,"-");
		strcpy(m[i].catatan_doktor,"-");
		strcpy(m[i].resep,"-");
	}
}
void inputDataKartuPasien(pasien m[])
{
	int i;
	for(i=0;i<5;i++){
	printf("Masukan ID pasien: ");scanf("%d", &m[i].id_pasien);
	printf("Masukan Nama: ");scanf("%s", &m[i].nama);
	printf("Masukan Jenis Kelamin: ");scanf("%s", &m[i].kelamin);
	//tanggal lahir
	printf("Maukan Tanggal Lahir: ");scanf("%d", &m[i].tgl_lahir.tanggal);
	printf("Masukan Bulan Lahir: ");scanf("%s", &m[i].tgl_lahir.bulan);
	printf("Masukan Tahun Lahir: ");scanf("%d", &m[i].tgl_lahir.tahun);
	
	printf("Masukan Golongan Darah: ");scanf("%s", &m[i].gol_darah);
	//alamat
	printf("Maukan nama jalan tempat tinggal anda : ");scanf("%s", &m[i].alamat.jalan);
	printf("Maukan nomer jalan tempat tinggal anda: ");scanf("%d", &m[i].alamat.no_jln);
	printf("Masukan kota tempat tinggal anda: ");scanf("%s", &m[i].alamat.kota);
	
	printf("Maukan Nomor KTP: ");scanf("%d", &m[i].ktp);
	printf("Masukan Nomor BPJS: ");scanf("%d", &m[i].bpjs);
	printf("Masukan Nomor Telpon: ");scanf("%d", &m[i].tlp);
	//tanggal daftar
	printf("Masukan tanggal daftar: ");scanf("%d", &m[i].tgl_daftar.tanggal);
	printf("Masukan bulan daftar: ");scanf("%s", &m[i].tgl_daftar.bulan);
	printf("Masukan tahun daftar: ");scanf("%d", &m[i].tgl_daftar.tahun);
	
	printf("Masukan doktor: ");scanf("%s", &m[i].doktor);
	
	}
}
void inputDataRiwayatPasien(pasien m[])
{
	int i;
	for(i=0;i<5;i++){
	//tanggal priksa
	printf("Masukan Tanggal Priksa: ");scanf("%d", &m[i].tgl_priksa.tanggal);
	printf("Masukan Bulan Priksa: ");scanf("%s", &m[i].tgl_priksa.bulan);
	printf("Masukan Tahun Priksa: ");scanf("%d", &m[i].tgl_priksa.tahun);
	printf("Masukan ID riwayat: ");scanf("%d", &m[i].id_riwayat);
	printf("Masukan Tinggi Badan: ");scanf("%d", &m[i].t_badan);
	printf("Masukan Berat Badan: ");scanf("%d", &m[i].b_badan);
	printf("Masukan Umur: ");scanf("%d", &m[i].umur);
	printf("Masukan Tekanan Darah: ");scanf("%d", &m[i].tekanan_darah);
	printf("Masukan Keluhan: ");scanf("%s", &m[i].keluhan);
	printf("Masukan Catatan Dokter: ");scanf("%s", &m[i].catatan_doktor);
	printf("Masukan Resep: ");scanf("%s", &m[i].resep);
	}
}
void kartu(pasien m[])
{
	int i;
	puts("\n======kartu kesehatan pasien =====");
	for(i=0;i<5;i++){
		printf("ID pasien\t %d\n",m[i].id_pasien);
		printf("Nama\t %s\n",m[i].nama);
		printf("Jenis Kelamin\t %s\n",m[i].kelamin);
		//tanggal lahir
		printf("Tgl Lahir\t %d/%s/%d\n\n",m[i].tgl_lahir.tanggal,m[i].tgl_lahir.bulan,m[i].tgl_lahir.tahun,m[i]);
		printf("Golongan Darah\t %s\n",m[i].gol_darah);
		//alamat
		printf("Alamat :\t Jl %s No %d, %s\n",m[i].alamat.jalan,m[i].alamat.no_jln,m[i].alamat.kota,m[i]);
		printf("No.KTP\t %d\n",m[i].ktp);
		printf("No.BPJS/Askes\t %d\n",m[i].bpjs);
		printf("NO.Telepon\t %d\n",m[i].tlp);
		//tanggal daftar
		printf("Tanggal Daftar\t %d/%s/%d\n\n",m[i].tgl_daftar.tanggal,m[i].tgl_daftar.bulan,m[i].tgl_daftar.tahun,m[i]);
		printf("Dokter Pribadi\t %s\n",m[i].doktor);
	}
}
void riwayatPasien(pasien m[])
{
	int i;
	puts("\n======Riwayat pasien =====");
	for(i=0;i<5;i++){
		//tnggal priksa
		printf("Tanggal Priksa\t %d/%s/%d\n",m[i].tgl_priksa.tanggal,m[i].tgl_priksa.bulan,m[i].tgl_priksa.tahun,m[i]);
		
		printf("ID Riwayat\t %d\n\n",m[i].id_riwayat);
		
		printf("Medical Checkup\n");
		printf("Tinggi Badan : \t %d\n",m[i].t_badan);
		printf("Berat Badan : \t %d\n",m[i].b_badan);
		printf("Umur : \t %d\n",m[i].umur);
		printf("Tekanan Darah : \t %d\n\n",m[i].tekanan_darah);
		printf("Keluhan : \t %s\n",m[i].keluhan);
		printf("Catatan dokter : \t %s\n",m[i].catatan_doktor);
		printf("Resep : \t %s\n",m[i].resep);
	}
}
void updateDataKartu(pasien m[])
{
	int i;
	for(i=0;i<5;i++){
	printf("Masukan ID pasien: ");scanf("%d", &m[i].id_pasien);
	printf("Masukan Nama: ");scanf("%s", &m[i].nama);
	printf("Masukan Jenis Kelamin: ");scanf("%s", &m[i].kelamin);
	//tanggal lahir
	printf("Maukan Tanggal Lahir: ");scanf("%d", &m[i].tgl_lahir.tanggal);
	printf("Masukan Bulan Lahir: ");scanf("%s", &m[i].tgl_lahir.bulan);
	printf("Masukan Tahun Lahir: ");scanf("%d", &m[i].tgl_lahir.tahun);
	
	printf("Masukan Golongan Darah: ");scanf("%s", &m[i].gol_darah);
	//alamat
	printf("Maukan nama jalan tempat tinggal anda : ");scanf("%s", &m[i].alamat.jalan);
	printf("Maukan nomer jalan tempat tinggal anda: ");scanf("%d", &m[i].alamat.no_jln);
	printf("Masukan kota tempat tinggal anda: ");scanf("%s", &m[i].alamat.kota);
	
	printf("Maukan Nomor KTP: ");scanf("%d", &m[i].ktp);
	printf("Masukan Nomor BPJS: ");scanf("%d", &m[i].bpjs);
	printf("Masukan Nomor Telpon: ");scanf("%d", &m[i].tlp);
	//tanggal daftar
	printf("Masukan tanggal daftar: ");scanf("%d", &m[i].tgl_daftar.tanggal);
	printf("Masukan bulan daftar: ");scanf("%s", &m[i].tgl_daftar.bulan);
	printf("Masukan tahun daftar: ");scanf("%d", &m[i].tgl_daftar.tahun);
	
	printf("Masukan doktor: ");scanf("%s", &m[i].doktor);
	
	}
}
void updateDataRiwayat(pasien m[])
{
	
	int i;
	for(i=0;i<5;i++){
	//tanggal priksa
	printf("Masukan Tanggal Priksa: ");scanf("%d", &m[i].tgl_priksa.tanggal);
	printf("Masukan Bulan Priksa: ");scanf("%s", &m[i].tgl_priksa.bulan);
	printf("Masukan Tahun Priksa: ");scanf("%d", &m[i].tgl_priksa.tahun);
	printf("Masukan ID riwayat: ");scanf("%d", &m[i].id_riwayat);
	printf("Masukan Tinggi Badan: ");scanf("%d", &m[i].t_badan);
	printf("Masukan Berat Badan: ");scanf("%d", &m[i].b_badan);
	printf("Masukan Umur: ");scanf("%d", &m[i].umur);
	printf("Masukan Tekanan Darah: ");scanf("%d", &m[i].tekanan_darah);
	printf("Masukan Keluhan: ");scanf("%s", &m[i].keluhan);
	printf("Masukan Catatan Dokter: ");scanf("%s", &m[i].catatan_doktor);
	printf("Masukan Resep: ");scanf("%s", &m[i].resep);
	}
}
void deleteDataKartu(pasien m[])
{
	int i;
	for (i=0;i<5;i++){
		m[i].id_pasien=0;
		strcpy(m[i].nama,"-");
		strcpy(m[i].kelamin,"-");
		//tanggal lahir
		m[i].tgl_lahir.tanggal=0;
		strcpy(m[i].tgl_lahir.bulan,"-");
		m[i].tgl_lahir.tahun=0;
		strcpy(m[i].gol_darah,"-");
		//alamat
		strcpy(m[i].alamat.jalan,"-");
		m[i].alamat.no_jln=0;
		strcpy(m[i].alamat.kota,"-");
		m[i].ktp=0;
		m[i].bpjs=0;
		m[i].tlp=0;
		//tanggal priksa
		m[i].tgl_daftar.tanggal=0;
		strcpy(m[i].tgl_daftar.bulan,"-");
		m[i].tgl_daftar.tahun=0;
		
		strcpy(m[i].doktor,"-");
	}
}
void deleteDataRiwayat(pasien m[])
{
	int i;
	for (i=0;i<5;i++){
		//tanggal priksa
		m[i].tgl_priksa.tanggal=0;
		strcpy(m[i].tgl_priksa.bulan,"-");
		m[i].tgl_priksa.tahun=0;
		
		m[i].id_riwayat=0;
		m[i].t_badan=0;
		m[i].b_badan=0;
		m[i].umur=0;
		m[i].tekanan_darah=0;
		strcpy(m[i].keluhan,"-");
		strcpy(m[i].catatan_doktor,"-");
		strcpy(m[i].resep,"-");
	}
}
